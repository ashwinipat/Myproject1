package com.cybage.executionmanagement.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.cybage.executionmanagement.dto.TestExecutionDTO;
import com.cybage.executionmanagement.model.TestExecutionModel;
import com.cybage.executionmanagement.service.TestExecutionService;

@RestController
@RequestMapping("/testExecution")
public class TestExecutionWebController {
	@Autowired
	TestExecutionService testExecutionService;

	// working add
	@RequestMapping(value = "/addTestExecuton", method = RequestMethod.POST, headers = "Accept=application/json")
	public void getTestExecution(@RequestBody TestExecutionDTO testExecutiondto) {
		System.out.println("Test Execution Id" + testExecutiondto.getTestExcutionId());
		ModelMapper modelMapper = new ModelMapper();
		TestExecutionModel testExecutionModel = modelMapper.map(testExecutiondto, TestExecutionModel.class);
		testExecutionService.insertIntoDb(testExecutionModel);
	}

	// working delete
	@RequestMapping(value = "/deleteTestExecution/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public TestExecutionDTO getTestExecution(@PathVariable int id) {
		TestExecutionModel testExecutionModel = null;
		testExecutionModel = testExecutionService.deleteTestExecution(id, testExecutionModel);
		ModelMapper modelMapper = new ModelMapper();
		TestExecutionDTO testExecutionDTO = modelMapper.map(testExecutionModel, TestExecutionDTO.class);
		return testExecutionDTO;
	}

	// working allvalues
	@RequestMapping(value = "/allTestExecution/", method = RequestMethod.GET)
	public ResponseEntity<List<TestExecutionModel>> listAllExecutions() {
		List<TestExecutionModel> testExecutionModel = testExecutionService.showAll();
		if (testExecutionModel.isEmpty()) {
			return new ResponseEntity<List<TestExecutionModel>>(HttpStatus.NO_CONTENT);// You
																						// many
																						// decide
																						// to
																						// return
																						// HttpStatus.NOT_FOUND
		}
		return new ResponseEntity<List<TestExecutionModel>>(testExecutionModel, HttpStatus.OK);
	}

	// working
	// hardcoded edit working give json data in body
	@RequestMapping(value = "/edit/updateTestScript", method = RequestMethod.POST)
	public ResponseEntity<List<TestExecutionModel>> addStudent(@RequestBody TestExecutionModel testExecutionModel) {

		TestExecutionModel tm1 = testExecutionService.updateIntoDB(testExecutionModel);

		List<TestExecutionModel> testExecutionModelList = testExecutionService.showAll();
		if (testExecutionModelList.isEmpty()) {
			return new ResponseEntity<List<TestExecutionModel>>(HttpStatus.NO_CONTENT);

		}
		return new ResponseEntity<List<TestExecutionModel>>(testExecutionModelList, HttpStatus.OK);
	}

	@RequestMapping(value = "/retrive/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<TestExecutionModel> getUser(@PathVariable("id") int id) {
		System.out.println("Fetching User with id " + id);
		TestExecutionModel user = testExecutionService.findById(id);
		if (user == null) {
			System.out.println("User with id " + id + " not found");
			return new ResponseEntity<TestExecutionModel>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<TestExecutionModel>(user, HttpStatus.OK);
	}

	/*
	 * @RequestMapping(value = "/user/{id}", method = RequestMethod.POST) public
	 * ResponseEntity<TestExecutionModel> updateUser(@PathVariable("id") long
	 * id, @RequestBody TestExecutionModel user) { System.out.println(
	 * "Updating User " + id);
	 * 
	 * TestExecutionModel currentUser = null ;
	 * 
	 * currentUser.setTestExcutionTitle(user.getTestExcutionTitle());
	 * currentUser.setTestExcutionRunsOn(user.getTestExcutionRunsOn());
	 * currentUser.setTestExcutionRunsTestCase(user.getTestExcutionRunsTestCase(
	 * )); currentUser.setTestExcutionResult(user.getTestExcutionResult());
	 * currentUser.setTestExcutionStatus(user.getTestExcutionStatus());
	 * 
	 * testExecutionService.updateUser(currentUser); return new
	 * ResponseEntity<TestExecutionModel>(currentUser, HttpStatus.OK); }
	 */
	/*
	 * @RequestMapping(value = "/getTestExecution1/{id}", method =
	 * RequestMethod.POST, headers = "Accept=application/json") public
	 * ResponseEntity<TestExecutionModel> getTestExecution1(@RequestBody
	 * TestExecutionModel user) {
	 * 
	 * TestExecutionModel currentUser = null ;
	 * 
	 * 
	 * 
	 * currentUser.setTestExcutionTitle(user.getTestExcutionTitle());
	 * currentUser.setTestExcutionRunsOn(user.getTestExcutionRunsOn());
	 * currentUser.setTestExcutionRunsTestCase(user.getTestExcutionRunsTestCase(
	 * )); currentUser.setTestExcutionResult(user.getTestExcutionResult());
	 * currentUser.setTestExcutionStatus(user.getTestExcutionStatus());
	 * 
	 * testExecutionService.updateIntoDB(currentUser); return new
	 * ResponseEntity<TestExecutionModel>(currentUser, HttpStatus.OK);
	 * 
	 * 
	 * }
	 */
}