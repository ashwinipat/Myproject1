package com.cybage.executionmanagement.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cybage.executionmanagement.model.TestExecutionModel;
import com.cybage.executionmanagement.service.TestExecutionService;

@Controller
public class TestExecutionController {
	@Autowired
	TestExecutionService testExecutionService;

	// To view add test script form
	@RequestMapping("/add")
	public ModelAndView showMessage1(@ModelAttribute("SpringWeb") TestExecutionModel testExecutionModel) {

		return new ModelAndView("addNewTestExecution", "command", testExecutionModel);
	}

	// insert new test script into database
	@RequestMapping("/insert")
	public ModelAndView addTestExecution(@RequestParam(value = "id", required = false, defaultValue = "1") int id,
			HttpServletRequest request, ModelMap model,
			@ModelAttribute("SpringWeb") TestExecutionModel testExecutionModel) {

		TestExecutionModel testExecutionModel1 = testExecutionService.insertIntoDb(testExecutionModel);

		ModelMapper modelMapper = new ModelMapper();

		List<TestExecutionModel> testExecutionList = testExecutionService.showAll();

		model.addAttribute("testExecutionList", testExecutionList);

		return new ModelAndView("allTestExecutions");
	}

	// To view list of all test scripts(select query)
	@RequestMapping("/view")
	public ModelAndView showMessage2(@RequestParam(value = "id", required = false, defaultValue = "1") String id,
			HttpServletRequest request, ModelMap model) {

		List<TestExecutionModel> testExecutionList = testExecutionService.showAll();

		model.addAttribute("testExecutionList", testExecutionList);

		return new ModelAndView("allTestExecutions");

	}

	// delete test script
	@RequestMapping("/delete/{id}")
	public ModelAndView deleteTestExecution(@PathVariable int id, HttpServletRequest request,
			@ModelAttribute("SpringWeb") TestExecutionModel testScriptModel) {

		TestExecutionModel testScriptModel1 = testExecutionService.deleteTestExecution(id, testScriptModel);

		return new ModelAndView("redirect:/view");
	}

	// fetch clicked test script into view from database
	@RequestMapping("/edit/{id}")
	public ModelAndView editTestExecution(@PathVariable int id, HttpServletRequest request) {

		TestExecutionModel testExecutionModel = testExecutionService.editTestExecution(id);

		return new ModelAndView("editTestExecution", "command", testExecutionModel);
	}

	// update the particular record into database
	@RequestMapping(value = "/edit/updateTestScript", method = RequestMethod.POST)
	public ModelAndView addStudent(@ModelAttribute("SpringWeb") TestExecutionModel testExecutionModel, ModelMap model) {

		TestExecutionModel tm1 = testExecutionService.updateIntoDB(testExecutionModel);

		List<TestExecutionModel> testExecutionList = testExecutionService.showAll();

		model.addAttribute("testExecutionList", testExecutionList);

		return new ModelAndView("redirect:/view");
	}

}
