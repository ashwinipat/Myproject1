package com.cybage.executionmanagement.dao;

import java.util.List;

import com.cybage.executionmanagement.model.TestExecutionModel;

public interface TestExecutionDao {

	TestExecutionModel getTestExcution(String testExcutionId);

	TestExecutionModel InsertIntoDB(TestExecutionModel testExecutionModel);

	List<TestExecutionModel> showAllTestCase();

	TestExecutionModel deleteTestExecution(int testExcutionId, TestExecutionModel testExecutionModel);

	TestExecutionModel editTestExecution(int testExcutionId);

	TestExecutionModel updateIntoDB(TestExecutionModel testExecutionModel);
	
}
