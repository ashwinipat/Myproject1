package com.cybage.executionmanagement.service;

import java.util.List;

import com.cybage.executionmanagement.model.TestExecutionModel;

public interface TestExecutionService {
	TestExecutionModel getTestExecution(String id);
	TestExecutionModel insertIntoDb(TestExecutionModel testExecutionModel);

	List<TestExecutionModel> showAll();

	TestExecutionModel deleteTestExecution(int id, TestExecutionModel tm);

	TestExecutionModel editTestExecution(int id);

	TestExecutionModel updateIntoDB(TestExecutionModel tm);
	TestExecutionModel findById(int id);
    void updateUser(TestExecutionModel user);

}
